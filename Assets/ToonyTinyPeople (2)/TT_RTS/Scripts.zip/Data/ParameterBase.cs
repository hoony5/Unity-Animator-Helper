﻿[System.Serializable]
public class ParameterBase
{
    public float threshold;
    public string name;
}