using UnityEditor.Animations;

[System.Serializable]
public class TransitionConditionSetting
{
    public AnimatorConditionMode mode;
    public ParameterBase parameterBase;
}