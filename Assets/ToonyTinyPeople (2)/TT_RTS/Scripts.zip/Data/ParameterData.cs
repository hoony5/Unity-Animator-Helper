
[System.Serializable]
public class ParameterData
{
    public string parameterName;
    public UnityEngine.AnimatorControllerParameterType parameterType;
}