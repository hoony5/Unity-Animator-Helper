using UnityEditor;
using UnityEditor.Animations;
using UnityEditorInternal;
using UnityEngine;
using static CustomEditorUtility;

[CustomEditor(typeof(AnimatorUtil))]
public class AnimatorUtilEditor : Editor
{
    private AnimatorUtil data;
    private ReorderableList parameterDatas;
    private ReorderableList animatorSettings;
    
    private bool parameterFoldOut = false;
    private bool animatorSettingsFoldOut = false;
    private void OnEnable()
    {
        data = target as AnimatorUtil;
        parameterDatas = serializedObject.DrawReorderList("ParameterDatas");
        parameterDatas
            .DrawContents(
                2,
                "애니메이터 파라미터 관리",
                60,
                new[]
                {
                    (120, "키", 25, "parameterName"),
                    (80, "타입",40, "parameterType"),
                });
        animatorSettings = serializedObject.DrawReorderList("SettingsList");
        animatorSettings
            .DrawContents(
                0,
                "스테이트 & 트랜지션 관리",
                15,
                null);
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.BeginVertical();
      
        EditorGUILayout.Space(10);  // 파라미터
        parameterFoldOut = DrawFoldOut(parameterFoldOut, "파라미터 관리", parameterDatas.ApplyReorderLayoutList);
        DrawLine(2, Color.green);
        
        // 트랜지션 데이터
        animatorSettingsFoldOut = DrawFoldOut(animatorSettingsFoldOut, "스테이트 & 트랜지션 관리", animatorSettings.ApplyReorderLayoutList);
        DrawLine(2, Color.green);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.BeginVertical();
        EditorGUILayout.LabelField($"파라미터 초기화 코드");
        SerializedProperty snippetProperty = serializedObject.FindProperty("parameterNameSnippet");
        snippetProperty.stringValue = data.WriteSnippetSetParameter();
        EditorGUILayout.SelectableLabel
        (
            string.IsNullOrEmpty(snippetProperty.stringValue) ? "" : snippetProperty.stringValue,
            new GUIStyle(GUI.skin.textArea)
            {
                richText = true,
                padding = new RectOffset(10,10,10,10)
            },
            new GUILayoutOption[]
            {
                GUILayout.MinHeight(128),
                GUILayout.MaxHeight(256),
            });     
        EditorGUILayout.EndVertical();
        EditorGUILayout.Space(10);
        EditorGUILayout.BeginVertical();
        EditorGUILayout.LabelField($"파라미터 리셋 코드");
        SerializedProperty methodSnippetProperty = serializedObject.FindProperty("parameterResetSnippet");
        methodSnippetProperty.stringValue = data.WriteSnippetResetParameterMethod();
        EditorGUILayout.SelectableLabel
        (
            string.IsNullOrEmpty(methodSnippetProperty.stringValue) ? "" : methodSnippetProperty.stringValue,
            new GUIStyle(GUI.skin.textArea)
            {
                richText = true,
                padding = new RectOffset(10,10,10,10)
            },
            new GUILayoutOption[]
            {
                GUILayout.MinHeight(128),
                GUILayout.MaxHeight(256),
            }); 
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndHorizontal();
        DrawLine(2, Color.green);
        // 실행 버튼    q
        if (GUILayout.Button("Set Up", new GUILayoutOption[]{GUILayout.Height(32)}))
        {
            data.SetParameters();
            data.SetTransition();
        }
        EditorGUILayout.EndVertical();      
        serializedObject.ApplyModifiedProperties();
    }
}
